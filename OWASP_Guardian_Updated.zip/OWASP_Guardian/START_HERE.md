# 🚀 How to Run OWASP Guardian + VulnCorp Target

## Step 1 — Install dependencies (one time only)
```bash
pip install flask requests beautifulsoup4
```

## Step 2 — Open TWO terminal windows

### Terminal 1 — Start the VULNERABLE TARGET (VulnCorp)
```bash
cd OWASP_Guardian
python vulnerable_dummy_app.py
```
→ Runs on **http://127.0.0.1:5001**

### Terminal 2 — Start the GUARDIAN SCANNER
```bash
cd OWASP_Guardian
python app.py
```
→ Runs on **http://127.0.0.1:5000**

## Step 3 — Open Guardian in your browser
```
http://127.0.0.1:5000
```
- Sign up / Log in
- On the Dashboard, enter target URL: `http://127.0.0.1:5001`
- Click **Scan**

## Step 4 — Try Attack Simulation
- Go to **Tools → Attack Sim**
- Target is pre-filled as `http://127.0.0.1:5001`
- Pick an attack type and click **Initialize Attack**

---

## VulnCorp Vulnerability Routes (for manual testing)

| Route | Vulnerability |
|-------|--------------|
| `http://127.0.0.1:5001/?name=<script>alert(1)</script>` | Reflected XSS |
| `http://127.0.0.1:5001/login` (user: `' OR '1'='1' --`) | SQL Injection |
| `http://127.0.0.1:5001/search?q=' UNION SELECT username,password,role FROM users--` | SQLi UNION dump |
| `http://127.0.0.1:5001/admin?admin=1` | Broken Access Control |
| `http://127.0.0.1:5001/upload` | Insecure File Upload |
| `http://127.0.0.1:5001/debug-info` | Sensitive Data Exposure |
| `http://127.0.0.1:5001/api/users` | Unauthenticated API |
| `http://127.0.0.1:5001/comment` | Stored XSS |
