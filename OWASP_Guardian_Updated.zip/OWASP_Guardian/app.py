from flask import Flask, render_template, request, redirect, session, url_for
import sqlite3, hashlib, requests, re, datetime, os
from bs4 import BeautifulSoup
import urllib.parse

app = Flask(__name__)
app.secret_key = "guardian_secret_key_change_this"

DB = "guardian.db"

# ─────────────────────────────────────────────
# DATABASE SETUP
# ─────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect(DB, timeout=20)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()

    # Users table
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT    UNIQUE NOT NULL,
            password TEXT    NOT NULL,
            email    TEXT,
            created  TEXT    DEFAULT (datetime('now'))
        )
    """)

    # Scans table
    c.execute("""
        CREATE TABLE IF NOT EXISTS scans (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL,
            url        TEXT    NOT NULL,
            score      INTEGER DEFAULT 0,
            high       INTEGER DEFAULT 0,
            medium     INTEGER DEFAULT 0,
            low        INTEGER DEFAULT 0,
            scan_date  TEXT    DEFAULT (datetime('now')),
            risk_level TEXT    DEFAULT 'LOW',
            insight    TEXT    DEFAULT '',
            issues     TEXT    DEFAULT '',
            app_type   TEXT    DEFAULT 'Web Application',
            auth_type  TEXT    DEFAULT 'No Authentication',
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    # Scheduled Scans table
    c.execute("""
        CREATE TABLE IF NOT EXISTS scheduled_scans (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL,
            url        TEXT    NOT NULL,
            frequency  TEXT    DEFAULT 'Daily',
            last_run   TEXT    DEFAULT NULL,
            next_run   TEXT    NOT NULL,
            app_type   TEXT    DEFAULT 'Web Application',
            auth_type  TEXT    DEFAULT 'No Authentication',
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    conn.commit()
    conn.close()

# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

def hash_password(pw):
    return hashlib.sha256(pw.encode()).hexdigest()

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated

def get_user_id():
    conn = get_db()
    row = conn.execute(
        "SELECT id FROM users WHERE username = ?", (session["user"],)
    ).fetchone()
    conn.close()
    return row["id"] if row else None

# ─────────────────────────────────────────────
# SCANNER ENGINE — FULL OWASP TOP 10
# ─────────────────────────────────────────────

def _add(issues, high, medium, low, msg, sev, cat):
    issues.append((msg, sev, cat))
    if sev == "HIGH":   high += 1
    elif sev == "MEDIUM": medium += 1
    else: low += 1
    return high, medium, low


def run_scan(url, app_type, auth_type):
    """
    Full OWASP Top 10 (2021) scanner.
    A01 Broken Access Control
    A02 Cryptographic Failures
    A03 Injection
    A04 Insecure Design
    A05 Security Misconfiguration
    A06 Vulnerable & Outdated Components
    A07 Identification & Auth Failures
    A08 Software & Data Integrity Failures
    A09 Security Logging & Monitoring Failures
    A10 Server-Side Request Forgery (SSRF)
    """
    issues = []
    high = medium = low = 0

    # Normalise URL
    if not url.startswith("http"):
        url = "https://" + url

    base = url.rstrip("/")
    session_req = requests.Session()
    session_req.headers.update({"User-Agent": "Guardian/1.0 Security Scanner"})

    try:
        resp    = session_req.get(url, timeout=12, verify=True, allow_redirects=True)
        headers = {k.lower(): v for k, v in resp.headers.items()}
        body    = resp.text
        body_lc = body.lower()
        status  = resp.status_code

        # ══════════════════════════════════════════
        # A01 — BROKEN ACCESS CONTROL
        # ══════════════════════════════════════════

        # Sensitive path exposure
        sensitive_paths = [
            "/admin", "/administrator", "/admin/login",
            "/config", "/config.php", "/config.yml", "/config.json",
            "/.env", "/.env.local", "/.env.production",
            "/backup", "/backup.zip", "/backup.sql", "/db.sql",
            "/phpinfo.php", "/info.php", "/test.php",
            "/.git/config", "/.git/HEAD",
            "/wp-admin", "/wp-config.php",
            "/api/users", "/api/admin", "/api/config",
            "/server-status", "/server-info",
            "/actuator", "/actuator/env", "/actuator/health",
        ]
        for path in sensitive_paths:
            try:
                r2 = session_req.get(base + path, timeout=5, allow_redirects=False)
                if r2.status_code == 200:
                    high, medium, low = _add(issues, high, medium, low,
                        f"Sensitive path accessible: {path}", "HIGH", "A01")
                elif r2.status_code == 403:
                    low, medium, low2 = _add(issues, 0, medium, low,
                        f"Path exists but access forbidden (may be bypassable): {path}", "LOW", "A01")
                    low = low2
            except: pass

        # Directory listing check
        dir_paths = ["/images/", "/uploads/", "/files/", "/static/", "/assets/"]
        for path in dir_paths:
            try:
                r2 = session_req.get(base + path, timeout=5, allow_redirects=False)
                if r2.status_code == 200 and "index of" in r2.text.lower():
                    high, medium, low = _add(issues, high, medium, low,
                        f"Directory listing enabled: {path}", "MEDIUM", "A01")
            except: pass

        # HTTP method check (TRACE/OPTIONS)
        try:
            r_trace = session_req.request("TRACE", url, timeout=5)
            if r_trace.status_code == 200:
                high, medium, low = _add(issues, high, medium, low,
                    "HTTP TRACE method enabled (Cross-Site Tracing risk)", "MEDIUM", "A01")
        except: pass

        try:
            r_opts = session_req.options(url, timeout=5)
            allow_hdr = r_opts.headers.get("allow", r_opts.headers.get("Allow", ""))
            if "DELETE" in allow_hdr or "PUT" in allow_hdr:
                high, medium, low = _add(issues, high, medium, low,
                    f"Dangerous HTTP methods allowed: {allow_hdr}", "HIGH", "A01")
        except: pass

        # ══════════════════════════════════════════
        # A02 — CRYPTOGRAPHIC FAILURES
        # ══════════════════════════════════════════

        # HTTP instead of HTTPS
        if url.startswith("http://"):
            high, medium, low = _add(issues, high, medium, low,
                "Site served over HTTP — all data transmitted in plaintext", "HIGH", "A02")

        # HSTS header
        if "strict-transport-security" not in headers:
            high, medium, low = _add(issues, high, medium, low,
                "HSTS (Strict-Transport-Security) header missing", "MEDIUM", "A02")
        else:
            hsts_val = headers["strict-transport-security"]
            if "max-age" in hsts_val:
                try:
                    age = int(re.search(r"max-age=(\d+)", hsts_val).group(1))
                    if age < 31536000:
                        high, medium, low = _add(issues, high, medium, low,
                            f"HSTS max-age too short: {age}s (recommended: 31536000+)", "LOW", "A02")
                except: pass
            if "includesubdomains" not in hsts_val.lower():
                high, medium, low = _add(issues, high, medium, low,
                    "HSTS missing includeSubDomains directive", "LOW", "A02")

        # SSL/TLS check
        try:
            import ssl, socket
            hostname = re.sub(r"https?://", "", url).split("/")[0].split(":")[0]
            ctx = ssl.create_default_context()
            with ctx.wrap_socket(socket.socket(), server_hostname=hostname) as s:
                s.settimeout(5)
                s.connect((hostname, 443))
                cert     = s.getpeercert()
                protocol = s.version()
                cipher   = s.cipher()

            # Protocol version
            if protocol in ["TLSv1", "TLSv1.1", "SSLv2", "SSLv3"]:
                high, medium, low = _add(issues, high, medium, low,
                    f"Outdated TLS protocol in use: {protocol} (upgrade to TLS 1.2+)", "HIGH", "A02")

            # Cipher strength
            if cipher and cipher[2] and cipher[2] < 128:
                high, medium, low = _add(issues, high, medium, low,
                    f"Weak cipher suite detected: {cipher[0]} ({cipher[2]}-bit)", "HIGH", "A02")

            # Certificate expiry
            expire_str = cert.get("notAfter", "")
            if expire_str:
                expire_dt = datetime.datetime.strptime(expire_str, "%b %d %H:%M:%S %Y %Z")
                days_left = (expire_dt - datetime.datetime.utcnow()).days
                if days_left < 0:
                    high, medium, low = _add(issues, high, medium, low,
                        "SSL certificate has EXPIRED", "HIGH", "A02")
                elif days_left < 30:
                    high, medium, low = _add(issues, high, medium, low,
                        f"SSL certificate expires in {days_left} days", "MEDIUM", "A02")

        except ssl.SSLError as e:
            high, medium, low = _add(issues, high, medium, low,
                f"SSL error: {str(e)}", "HIGH", "A02")
        except Exception:
            pass

        # Sensitive data in response
        sensitive_patterns = [
            (r'password\s*[:=]\s*["\']?\w+', "Password value exposed in response body", "HIGH"),
            (r'api[_-]?key\s*[:=]\s*["\']?[\w-]+', "API key exposed in response body", "HIGH"),
            (r'secret\s*[:=]\s*["\']?\w+', "Secret value exposed in response body", "HIGH"),
            (r'[a-zA-Z0-9+/]{40,}={0,2}', "Possible Base64-encoded sensitive data in response", "LOW"),
            (r'-----BEGIN (RSA |EC )?PRIVATE KEY-----', "Private key exposed in response", "HIGH"),
        ]
        for pattern, msg, sev in sensitive_patterns:
            if re.search(pattern, body, re.IGNORECASE):
                high, medium, low = _add(issues, high, medium, low, msg, sev, "A02")

        # ══════════════════════════════════════════
        # A03 — INJECTION
        # ══════════════════════════════════════════

        # SQL error patterns in response
        sql_errors = [
            "sql syntax", "mysql_fetch", "mysql_num_rows", "mysql_query",
            "ora-0", "ora-1", "pg::", "postgresql error",
            "sqlite_", "sqlite error", "microsoft ole db",
            "unclosed quotation mark", "quoted string not properly terminated",
            "syntax error near", "invalid query"
        ]
        for err in sql_errors:
            if err in body_lc:
                high, medium, low = _add(issues, high, medium, low,
                    f"SQL error message leaked in response: '{err}'", "HIGH", "A03")
                break

        # XSS patterns
        xss_patterns = [
            r'<script[^>]*>.*?(alert|confirm|prompt|eval)\s*\(',
            r'javascript\s*:\s*(alert|eval|document\.)',
            r'on(load|error|click|mouseover)\s*=\s*["\']?(alert|eval)',
        ]
        for pat in xss_patterns:
            if re.search(pat, body, re.IGNORECASE | re.DOTALL):
                high, medium, low = _add(issues, high, medium, low,
                    "Possible reflected XSS detected in response", "HIGH", "A03")
                break

        # Command injection indicators
        cmd_patterns = ["root:x:0:0", "/bin/bash", "uid=0(root)", "volume serial number"]
        for pat in cmd_patterns:
            if pat in body_lc:
                high, medium, low = _add(issues, high, medium, low,
                    f"Possible command injection output in response: '{pat}'", "HIGH", "A03")

        # LDAP/XPath/NoSQL injection markers
        if any(x in body_lc for x in ["ldap_bind", "ldap error", "xpath error", "xpathexception"]):
            high, medium, low = _add(issues, high, medium, low,
                "LDAP/XPath injection error detected in response", "HIGH", "A03")

        # Template injection
        if any(x in body_lc for x in ["{{", "}}", "freemarker", "velocity error", "thymeleaf"]):
            high, medium, low = _add(issues, high, medium, low,
                "Possible server-side template injection indicator found", "MEDIUM", "A03")

        # ══════════════════════════════════════════
        # A04 — INSECURE DESIGN
        # ══════════════════════════════════════════

        # No rate-limiting headers
        rate_limit_headers = ["x-ratelimit-limit", "x-rate-limit-limit",
                               "ratelimit-limit", "retry-after"]
        has_rate_limit = any(h in headers for h in rate_limit_headers)
        if not has_rate_limit and auth_type != "No Authentication":
            high, medium, low = _add(issues, high, medium, low,
                "No rate-limiting headers detected on authenticated endpoint", "MEDIUM", "A04")

        # Login page CAPTCHA / anti-brute-force check
        if auth_type != "No Authentication":
            has_captcha = any(x in body_lc for x in ["captcha", "recaptcha", "hcaptcha", "turnstile"])
            if not has_captcha:
                high, medium, low = _add(issues, high, medium, low,
                    "No CAPTCHA or brute-force protection detected on login", "MEDIUM", "A04")

        # Password policy indicators (look for weak hints)
        if "password" in body_lc:
            weak_hints = ["minimum 4", "min 4", "at least 4", "minimum 3", "min 3"]
            for hint in weak_hints:
                if hint in body_lc:
                    high, medium, low = _add(issues, high, medium, low,
                        f"Weak password policy hint detected: '{hint}'", "MEDIUM", "A04")

        # ══════════════════════════════════════════
        # A05 — SECURITY MISCONFIGURATION
        # ══════════════════════════════════════════

        # Security headers
        required_headers = {
            "x-frame-options":        ("X-Frame-Options missing — Clickjacking risk", "MEDIUM"),
            "x-content-type-options": ("X-Content-Type-Options missing — MIME sniffing risk", "LOW"),
            "content-security-policy":("Content-Security-Policy (CSP) header missing", "MEDIUM"),
            "referrer-policy":        ("Referrer-Policy header missing", "LOW"),
            "permissions-policy":     ("Permissions-Policy header missing", "LOW"),
            "cross-origin-opener-policy": ("COOP header missing", "LOW"),
            "cross-origin-resource-policy": ("CORP header missing", "LOW"),
        }
        for hdr, (msg, sev) in required_headers.items():
            if hdr not in headers:
                high, medium, low = _add(issues, high, medium, low, msg, sev, "A05")

        # CSP quality check
        if "content-security-policy" in headers:
            csp = headers["content-security-policy"].lower()
            if "unsafe-inline" in csp:
                high, medium, low = _add(issues, high, medium, low,
                    "CSP contains 'unsafe-inline' — XSS protections weakened", "MEDIUM", "A05")
            if "unsafe-eval" in csp:
                high, medium, low = _add(issues, high, medium, low,
                    "CSP contains 'unsafe-eval' — code injection risk", "MEDIUM", "A05")
            if "*" in csp and "default-src" in csp:
                high, medium, low = _add(issues, high, medium, low,
                    "CSP uses wildcard (*) in default-src — overly permissive", "LOW", "A05")

        # Server/tech disclosure
        if "server" in headers:
            sv = headers["server"]
            if re.search(r"\d+\.\d+", sv):
                high, medium, low = _add(issues, high, medium, low,
                    f"Server version disclosed: {sv}", "LOW", "A05")

        if "x-powered-by" in headers:
            high, medium, low = _add(issues, high, medium, low,
                f"X-Powered-By header exposes tech stack: {headers['x-powered-by']}", "LOW", "A05")

        if "x-aspnet-version" in headers:
            high, medium, low = _add(issues, high, medium, low,
                f"X-AspNet-Version exposed: {headers['x-aspnet-version']}", "LOW", "A05")

        if "x-aspnetmvc-version" in headers:
            high, medium, low = _add(issues, high, medium, low,
                "X-AspNetMvc-Version header exposes framework version", "LOW", "A05")

        # Default error pages / stack traces
        error_indicators = [
            ("traceback (most recent call last)", "Python stack trace exposed in response"),
            ("at java.lang.", "Java stack trace exposed in response"),
            ("system.web.httpexception", ".NET exception exposed in response"),
            ("fatal error:", "PHP fatal error exposed in response"),
            ("warning: ", "PHP warning exposed in response"),
            ("notice: ", "PHP notice exposed in response"),
            ("parse error:", "PHP parse error exposed in response"),
        ]
        for pattern, msg in error_indicators:
            if pattern in body_lc:
                high, medium, low = _add(issues, high, medium, low, msg, "MEDIUM", "A05")

        # Debug mode indicators
        debug_indicators = ["debug mode", "werkzeug debugger", "django debug",
                            "__debug__", "debug=true", "debugmode=on"]
        for di in debug_indicators:
            if di in body_lc:
                high, medium, low = _add(issues, high, medium, low,
                    f"Debug mode appears to be enabled: '{di}'", "HIGH", "A05")
                break

        # Default credentials page check
        default_cred_paths = ["/login", "/admin/login", "/user/login"]
        for path in default_cred_paths:
            try:
                r2 = session_req.post(base + path, timeout=5,
                    data={"username": "admin", "password": "admin"},
                    allow_redirects=False)
                if r2.status_code in [200, 302] and \
                   any(x in r2.headers.get("location","").lower() for x in ["dashboard","home","admin"]):
                    high, medium, low = _add(issues, high, medium, low,
                        f"Default credentials (admin/admin) accepted at {path}", "HIGH", "A05")
            except: pass

        # ══════════════════════════════════════════
        # A06 — VULNERABLE & OUTDATED COMPONENTS
        # ══════════════════════════════════════════

        # jQuery version check
        jquery_match = re.search(r'jquery[.-](\d+\.\d+\.?\d*)(\.min)?\.js', body_lc)
        if jquery_match:
            jq_ver = jquery_match.group(1)
            major, minor = int(jq_ver.split(".")[0]), int(jq_ver.split(".")[1])
            if major < 3 or (major == 3 and minor < 6):
                high, medium, low = _add(issues, high, medium, low,
                    f"Outdated jQuery detected: v{jq_ver} (recommend 3.7+)", "MEDIUM", "A06")

        # Bootstrap version check
        bs_match = re.search(r'bootstrap[.-](\d+\.\d+\.?\d*)(\.min)?\.(?:js|css)', body_lc)
        if bs_match:
            bs_ver = bs_match.group(1)
            major = int(bs_ver.split(".")[0])
            if major < 5:
                high, medium, low = _add(issues, high, medium, low,
                    f"Outdated Bootstrap detected: v{bs_ver} (recommend v5+)", "LOW", "A06")

        # Outdated server software
        if "server" in headers:
            sv = headers["server"].lower()
            outdated_servers = {
                "apache/2.2": "Apache 2.2 is end-of-life",
                "apache/2.4.4": "Apache 2.4.4 has known vulnerabilities",
                "nginx/1.12": "Nginx 1.12 is outdated",
                "nginx/1.14": "Nginx 1.14 is outdated",
                "iis/7": "IIS 7 is end-of-life",
                "iis/8": "IIS 8 is end-of-life",
                "php/5": "PHP 5.x is end-of-life with known RCE vulnerabilities",
                "php/7.0": "PHP 7.0 is end-of-life",
                "php/7.1": "PHP 7.1 is end-of-life",
                "php/7.2": "PHP 7.2 is end-of-life",
            }
            for sig, msg in outdated_servers.items():
                if sig in sv:
                    high, medium, low = _add(issues, high, medium, low,
                        f"Outdated server software: {msg}", "HIGH", "A06")

        # WordPress version disclosure
        wp_match = re.search(r'wordpress[\s/]+([\d.]+)', body_lc)
        if wp_match:
            high, medium, low = _add(issues, high, medium, low,
                f"WordPress version disclosed: {wp_match.group(1)}", "MEDIUM", "A06")

        # Known vulnerable JS libraries in page source
        vuln_libs = {
            "angular.js/1.": "AngularJS 1.x is end-of-life",
            "prototype.js": "Prototype.js has known XSS vulnerabilities",
            "mootools": "MooTools has known vulnerabilities",
        }
        for lib, msg in vuln_libs.items():
            if lib in body_lc:
                high, medium, low = _add(issues, high, medium, low, msg, "MEDIUM", "A06")

        # ══════════════════════════════════════════
        # A07 — IDENTIFICATION & AUTHENTICATION FAILURES
        # ══════════════════════════════════════════

        # Cookie security flags
        all_cookies = resp.cookies
        set_cookie_hdr = headers.get("set-cookie", "")

        if set_cookie_hdr:
            ck = set_cookie_hdr.lower()
            if "httponly" not in ck:
                high, medium, low = _add(issues, high, medium, low,
                    "Session cookie missing HttpOnly flag — accessible via JavaScript", "HIGH", "A07")
            if "secure" not in ck:
                high, medium, low = _add(issues, high, medium, low,
                    "Session cookie missing Secure flag — sent over HTTP", "HIGH", "A07")
            if "samesite" not in ck:
                high, medium, low = _add(issues, high, medium, low,
                    "Session cookie missing SameSite attribute — CSRF risk", "MEDIUM", "A07")

            # Session cookie name reveals technology
            session_cookies = ["phpsessid", "jsessionid", "asp.net_sessionid", "cfid", "cftoken"]
            for sc in session_cookies:
                if sc in ck:
                    high, medium, low = _add(issues, high, medium, low,
                        f"Session cookie name reveals server technology: {sc.upper()}", "LOW", "A07")

        # Weak session token entropy check
        for cookie in all_cookies:
            if len(cookie.value) < 16:
                high, medium, low = _add(issues, high, medium, low,
                    f"Short session token detected ({len(cookie.value)} chars) — low entropy risk", "MEDIUM", "A07")

        # Autocomplete on password fields
        if re.search(r'<input[^>]+type=["\']?password[^>]*>', body, re.IGNORECASE):
            if not re.search(r'<input[^>]+type=["\']?password[^>]+autocomplete=["\']?off',
                             body, re.IGNORECASE):
                high, medium, low = _add(issues, high, medium, low,
                    "Password field missing autocomplete='off' attribute", "LOW", "A07")

        # No account lockout / brute force protection
        if auth_type != "No Authentication":
            try:
                failed_attempts = 0
                for _ in range(3):
                    r2 = session_req.post(url, timeout=5,
                        data={"username": "test_user_guardian",
                              "password": "wrong_pass_guardian_test"},
                        allow_redirects=True)
                    if r2.status_code == 200:
                        failed_attempts += 1
                if failed_attempts >= 3:
                    high, medium, low = _add(issues, high, medium, low,
                        "No account lockout detected after 3 failed login attempts", "HIGH", "A07")
            except: pass

        # JWT in response
        jwt_match = re.search(r'eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+', body)
        if jwt_match:
            token = jwt_match.group(0)
            # Check for 'alg: none' in JWT header
            try:
                import base64
                header_b64 = token.split(".")[0]
                header_b64 += "=" * (4 - len(header_b64) % 4)
                header_json = base64.urlsafe_b64decode(header_b64).decode("utf-8", errors="ignore")
                if '"alg":"none"' in header_json or '"alg": "none"' in header_json:
                    high, medium, low = _add(issues, high, medium, low,
                        "JWT token uses 'none' algorithm — signature bypass possible", "HIGH", "A07")
                elif '"alg":"HS256"' not in header_json and '"alg":"RS256"' not in header_json:
                    high, medium, low = _add(issues, high, medium, low,
                        "JWT token detected with potentially weak/missing algorithm", "MEDIUM", "A07")
            except: pass

        # ══════════════════════════════════════════
        # A08 — SOFTWARE & DATA INTEGRITY FAILURES
        # ══════════════════════════════════════════

        # Subresource Integrity (SRI) check for external scripts
        external_scripts = re.findall(
            r'<script[^>]+src=["\']?(https?://[^"\'>\s]+)["\']?[^>]*>', body, re.IGNORECASE)
        for src in external_scripts:
            if "integrity" not in body[body.lower().find(src.lower())-20:
                                       body.lower().find(src.lower())+200].lower():
                high, medium, low = _add(issues, high, medium, low,
                    f"External script loaded without SRI integrity attribute: {src[:80]}", "MEDIUM", "A08")
                break  # report once

        # Deserialization indicators
        deser_patterns = [
            "java.io.serializable", "aced0005", "rO0AB",  # Java serialized object
            "phpunserialize", "unserialize(",               # PHP unserialize
            "__reduce__", "pickle.loads",                   # Python pickle
        ]
        for pat in deser_patterns:
            if pat.lower() in body_lc:
                high, medium, low = _add(issues, high, medium, low,
                    f"Possible insecure deserialization indicator: '{pat}'", "HIGH", "A08")

        # No cache-control for sensitive pages
        cache_ctrl = headers.get("cache-control", "")
        if not cache_ctrl:
            high, medium, low = _add(issues, high, medium, low,
                "Cache-Control header missing — sensitive data may be cached", "LOW", "A08")
        elif "no-store" not in cache_ctrl.lower() and "private" not in cache_ctrl.lower():
            high, medium, low = _add(issues, high, medium, low,
                "Cache-Control does not prevent caching of sensitive responses", "LOW", "A08")

        # ══════════════════════════════════════════
        # A09 — SECURITY LOGGING & MONITORING FAILURES
        # ══════════════════════════════════════════

        # Verbose error / debug info
        verbose_patterns = [
            ("traceback", "Stack traceback exposed in response"),
            ("debug info", "Debug information exposed"),
            ("error on line", "PHP error line number exposed"),
            ("call stack", "Call stack information exposed"),
            ("at line", "Error line information in response"),
        ]
        for pat, msg in verbose_patterns:
            if pat in body_lc:
                high, medium, low = _add(issues, high, medium, low, msg, "MEDIUM", "A09")

        # No Content-Type on response (can enable sniffing attacks)
        if "content-type" not in headers:
            high, medium, low = _add(issues, high, medium, low,
                "Missing Content-Type header — MIME sniffing attack possible", "MEDIUM", "A09")

        # No correlation/request IDs in headers (logging quality)
        tracking_headers = ["x-request-id", "x-correlation-id", "x-trace-id"]
        if not any(h in headers for h in tracking_headers):
            high, medium, low = _add(issues, high, medium, low,
                "No request tracking headers (X-Request-ID etc.) — limits log correlation", "LOW", "A09")

        # ══════════════════════════════════════════
        # A10 — SERVER-SIDE REQUEST FORGERY (SSRF)
        # ══════════════════════════════════════════

        # URL parameter SSRF indicators
        parsed_params = re.findall(r'[?&]([^=&]+)=([^&\s"\'<>]+)', url)
        ssrf_param_names = ["url", "uri", "path", "dest", "redirect", "next",
                            "target", "link", "src", "source", "fetch", "load",
                            "request", "proxy", "callback", "return"]
        for param_name, param_val in parsed_params:
            if param_name.lower() in ssrf_param_names:
                high, medium, low = _add(issues, high, medium, low,
                    f"Possible SSRF-prone URL parameter found: '{param_name}'", "MEDIUM", "A10")

        # SSRF in forms
        form_actions = re.findall(r'<form[^>]+action=["\']?([^"\'>\s]+)', body, re.IGNORECASE)
        for action in form_actions:
            if action.startswith("http") and not action.startswith(url):
                high, medium, low = _add(issues, high, medium, low,
                    f"Form submits to external URL — potential SSRF: {action[:80]}", "MEDIUM", "A10")

        # Open redirect check
        redirect_params = ["redirect", "next", "url", "return", "returnTo", "goto"]
        for param in redirect_params:
            try:
                test_ssrf = f"{base}?{param}=http://127.0.0.1"
                r2 = session_req.get(test_ssrf, timeout=5, allow_redirects=False)
                loc = r2.headers.get("location", "")
                if "127.0.0.1" in loc or "localhost" in loc:
                    high, medium, low = _add(issues, high, medium, low,
                        f"Open redirect to internal host via '{param}' parameter — SSRF risk", "HIGH", "A10")
            except: pass

        # Internal IP in response
        internal_ip_pattern = re.compile(
            r'(192\.168\.\d+\.\d+|10\.\d+\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+)')
        if internal_ip_pattern.search(body):
            high, medium, low = _add(issues, high, medium, low,
                "Internal IP address found in response body — SSRF/info disclosure risk", "MEDIUM", "A10")

    except requests.exceptions.SSLError as e:
        high, medium, low = _add(issues, high, medium, low,
            f"SSL/TLS error: {str(e)[:100]}", "HIGH", "A02")
    except requests.exceptions.ConnectionError:
        high, medium, low = _add(issues, high, medium, low,
            "Could not connect to target URL", "HIGH", "A05")
    except requests.exceptions.Timeout:
        high, medium, low = _add(issues, high, medium, low,
            "Connection timed out during scan", "MEDIUM", "A05")
    except Exception as e:
        high, medium, low = _add(issues, high, medium, low,
            f"Unexpected scan error: {str(e)[:100]}", "LOW", "A05")

    # ── Deduplicate ──
    seen = set()
    unique_issues = []
    for issue in issues:
        key = issue[0][:60]
        if key not in seen:
            seen.add(key)
            unique_issues.append(issue)
    issues = unique_issues

    # ── Score calculation ──
    deductions = (high * 12) + (medium * 6) + (low * 2)
    score = max(0, min(100, 100 - deductions))

    # ── Risk level ──
    if high >= 4 or score < 35:
        risk_level = "CRITICAL"
    elif high >= 2 or score < 55:
        risk_level = "HIGH"
    elif medium >= 3 or score < 75:
        risk_level = "MEDIUM"
    else:
        risk_level = "LOW"

    # ── Insight ──
    categories_hit = list(set(i[2] for i in issues))
    if not issues:
        insight = "No issues found. The target appears well-configured across all OWASP Top 10 checks."
    elif high >= 4:
        insight = (f"CRITICAL: {high} high-severity findings across {len(categories_hit)} OWASP "
                   f"categories. Immediate remediation required before production.")
    elif high > 0:
        insight = (f"{high} high-severity issue(s) found in: {', '.join(categories_hit[:3])}. "
                   f"Prioritise fixing these before any public exposure.")
    elif medium > 0:
        insight = (f"{medium} medium-severity issues detected across "
                   f"{len(categories_hit)} category(ies). Schedule fixes in next sprint.")
    else:
        insight = (f"{low} low-severity findings. Good security posture — "
                   f"address these to achieve hardened compliance.")

    # Convert issues list to string for storage
    issues_str = "|".join([f"{i[0]};{i[1]};{i[2]}" for i in issues])

    return score, high, medium, low, risk_level, insight, issues, issues_str


def parse_issues(issues_str):
    """Parse stored issues string back into list of tuples."""
    if not issues_str:
        return []
    result = []
    for item in issues_str.split("|"):
        parts = item.split(";")
        if len(parts) == 3:
            result.append((parts[0], parts[1], parts[2]))
    return result


# ─────────────────────────────────────────────
# OWASP REMEDIATION KNOWLEDGE BASE
# ─────────────────────────────────────────────

OWASP_REMEDIATION = {
    "A01": {
        "name": "Broken Access Control",
        "risk": "Attackers can act as other users, access unauthorized data, or perform privileged actions.",
        "what_companies_must_do": [
            "Deny access by default — only grant permissions explicitly.",
            "Implement role-based access control (RBAC) for every endpoint.",
            "Never expose admin panels, config files, or API endpoints without authentication.",
            "Log all access control failures and alert on repeated failures.",
            "Disable directory listing on all web servers.",
            "Disable HTTP TRACE and other unused HTTP methods.",
            "Use server-side session management — never rely on client-side access tokens alone.",
        ],
        "precautions": [
            "Conduct quarterly access reviews — remove stale permissions.",
            "Penetration test all authenticated routes before every release.",
            "Implement URL-based and object-level authorization checks.",
            "Use a WAF (Web Application Firewall) to block path traversal attacks.",
            "Never store sensitive files (`.env`, `.git`, backups) in the web root.",
        ],
        "fix_example": "Add @login_required and role checks to every sensitive route. Return 403 Forbidden instead of 404 to not reveal resource existence.",
        "compliance": ["GDPR Article 25", "PCI-DSS 6.5.8", "ISO 27001 A.9"],
    },
    "A02": {
        "name": "Cryptographic Failures",
        "risk": "Sensitive data (passwords, credit cards, health records) exposed in transit or at rest.",
        "what_companies_must_do": [
            "Enforce HTTPS everywhere — redirect all HTTP to HTTPS.",
            "Set HSTS header with max-age ≥ 31536000 and includeSubDomains.",
            "Use TLS 1.2 minimum — disable TLS 1.0, 1.1, SSLv2, SSLv3.",
            "Hash passwords with bcrypt, scrypt, or Argon2 — never MD5/SHA1.",
            "Encrypt all sensitive database columns (PII, payment data).",
            "Never store API keys, tokens, or secrets in source code or logs.",
            "Renew SSL certificates at least 30 days before expiry.",
        ],
        "precautions": [
            "Run SSL Labs scan (ssllabs.com) monthly — aim for A+ rating.",
            "Use a secrets manager (AWS Secrets Manager, HashiCorp Vault).",
            "Rotate encryption keys annually and after any suspected compromise.",
            "Never transmit sensitive data in URL parameters (visible in logs).",
            "Implement Certificate Transparency monitoring.",
        ],
        "fix_example": "flask-talisman enforces HTTPS + HSTS in one line: Talisman(app, force_https=True, strict_transport_security=True)",
        "compliance": ["PCI-DSS 4.1", "HIPAA §164.312(e)", "GDPR Article 32"],
    },
    "A03": {
        "name": "Injection",
        "risk": "Attackers inject malicious SQL, OS commands, or scripts — leading to full data compromise or server takeover.",
        "what_companies_must_do": [
            "Always use parameterized queries / prepared statements — never string-concatenate SQL.",
            "Use an ORM (SQLAlchemy, Django ORM) which handles escaping automatically.",
            "Validate and sanitize ALL user input — whitelist allowed characters.",
            "Escape HTML output to prevent XSS — use templating engines with auto-escaping.",
            "Never pass user input to OS commands (subprocess, exec, eval).",
            "Implement a Content Security Policy (CSP) to mitigate XSS impact.",
            "Disable detailed error messages in production — never expose stack traces.",
        ],
        "precautions": [
            "Run automated SAST (static analysis) tools on every pull request.",
            "Use a WAF with OWASP Core Rule Set to block injection attempts.",
            "Conduct regular code reviews focused on input handling.",
            "Test all input fields with automated fuzzing tools (OWASP ZAP, Burp Suite).",
            "Least privilege on DB accounts — app user should not have DROP/ALTER rights.",
        ],
        "fix_example": "BAD: cursor.execute(f'SELECT * FROM users WHERE id={user_id}')\nGOOD: cursor.execute('SELECT * FROM users WHERE id=?', (user_id,))",
        "compliance": ["PCI-DSS 6.5.1", "OWASP ASVS V5", "NIST SP 800-53 SI-10"],
    },
    "A04": {
        "name": "Insecure Design",
        "risk": "Fundamental business logic flaws that cannot be patched — require redesign.",
        "what_companies_must_do": [
            "Conduct threat modeling before development begins (STRIDE methodology).",
            "Implement rate limiting on all login, registration, and API endpoints.",
            "Add CAPTCHA or multi-step verification to prevent automated attacks.",
            "Enforce strong password policies (min 12 chars, complexity, breach-check).",
            "Design fail-safe defaults — deny everything, allow explicitly.",
            "Separate sensitive operations into isolated services with minimal access.",
            "Design for auditability — every sensitive action must be logged.",
        ],
        "precautions": [
            "Security requirements review in every sprint planning session.",
            "Engage a security architect during system design phase.",
            "Use OWASP ASVS as a security checklist for each feature.",
            "Red team exercises quarterly to find design-level weaknesses.",
            "Implement abuse case testing alongside normal user story testing.",
        ],
        "fix_example": "Implement exponential backoff: after 5 failed logins, lock account for 15 mins and send alert email. Use flask-limiter: @limiter.limit('5 per minute')",
        "compliance": ["ISO 27001 A.14", "NIST CSF PR.AC", "SOC 2 CC6"],
    },
    "A05": {
        "name": "Security Misconfiguration",
        "risk": "Default configs, exposed admin panels, verbose errors — attackers gather intelligence for targeted attacks.",
        "what_companies_must_do": [
            "Harden all server configurations before deploying to production.",
            "Remove all default credentials, sample apps, and unnecessary features.",
            "Set all security headers: CSP, X-Frame-Options, HSTS, X-Content-Type-Options.",
            "Disable server version disclosure (Server header, X-Powered-By).",
            "Never run Flask/Django in debug mode in production.",
            "Use environment-specific configs — never commit production secrets.",
            "Disable directory listing and unnecessary HTTP methods.",
        ],
        "precautions": [
            "Automated configuration scanning in CI/CD pipeline (Mozilla Observatory).",
            "Infrastructure-as-Code (IaC) security scanning (tfsec, checkov).",
            "Monthly CIS Benchmark compliance checks on all servers.",
            "Automated header checks on every deployment.",
            "Regular review of firewall rules — remove unused open ports.",
        ],
        "fix_example": "Set headers in Flask: response.headers['X-Frame-Options']='DENY'; response.headers['X-Content-Type-Options']='nosniff'. Or use flask-talisman.",
        "compliance": ["CIS Benchmarks", "PCI-DSS 2.2", "NIST SP 800-123"],
    },
    "A06": {
        "name": "Vulnerable & Outdated Components",
        "risk": "Known CVEs in libraries give attackers a ready-made exploit — no discovery work needed.",
        "what_companies_must_do": [
            "Maintain a complete software bill of materials (SBOM) for every project.",
            "Subscribe to CVE notifications for all dependencies used.",
            "Update all libraries monthly — critical vulnerabilities within 24-48 hours.",
            "Remove unused dependencies, frameworks, and features.",
            "Only use components from official, trusted sources.",
            "Verify integrity of downloaded packages (checksums, signatures).",
        ],
        "precautions": [
            "Integrate dependency scanning in CI/CD: pip-audit, npm audit, Snyk, Dependabot.",
            "Pin dependency versions in requirements.txt — avoid using latest/*.",
            "Set up automated Dependabot PRs for security updates.",
            "Container image scanning before every deployment (Trivy, Grype).",
            "End-of-life OS and runtime tracking — plan upgrades 6 months ahead.",
        ],
        "fix_example": "Run: pip install pip-audit && pip-audit\nFix: pip install --upgrade flask requests cryptography\nAutomate: Add pip-audit to your GitHub Actions workflow.",
        "compliance": ["PCI-DSS 6.3.3", "NIST SP 800-190", "CycloneDX SBOM standard"],
    },
    "A07": {
        "name": "Identification & Authentication Failures",
        "risk": "Account takeover, credential stuffing, session hijacking — leading to full user impersonation.",
        "what_companies_must_do": [
            "Implement multi-factor authentication (MFA) for all accounts — especially admin.",
            "Enforce account lockout after 5–10 failed login attempts.",
            "Use secure session management: regenerate session ID on login.",
            "Set cookie flags: HttpOnly, Secure, SameSite=Strict.",
            "Implement credential breach checking (HaveIBeenPwned API).",
            "Minimum password length of 12 characters with complexity requirements.",
            "Expire sessions after inactivity (30–60 minutes for sensitive apps).",
        ],
        "precautions": [
            "Implement real-time login anomaly detection (new country, device).",
            "Log all authentication events with IP, timestamp, user agent.",
            "Use short-lived JWT tokens (15 min access, 7 day refresh).",
            "Store passwords only with Argon2id or bcrypt (cost factor ≥ 12).",
            "Implement CAPTCHA after 3 failed login attempts.",
            "Notify users by email on new login from unrecognized device.",
        ],
        "fix_example": "from werkzeug.security import generate_password_hash, check_password_hash\nhash = generate_password_hash(password, method='pbkdf2:sha256', salt_length=16)",
        "compliance": ["NIST SP 800-63B", "PCI-DSS 8.2", "GDPR Article 32"],
    },
    "A08": {
        "name": "Software & Data Integrity Failures",
        "risk": "Supply chain attacks, malicious updates, or tampered code deployed to production.",
        "what_companies_must_do": [
            "Add Subresource Integrity (SRI) hashes to all external scripts and stylesheets.",
            "Sign all software releases and verify signatures before deployment.",
            "Use trusted CI/CD pipelines with access controls and audit logs.",
            "Never deserialize untrusted data — validate and sanitize before processing.",
            "Implement code signing for all deployment artifacts.",
            "Verify integrity of all third-party integrations and webhooks.",
        ],
        "precautions": [
            "Enable branch protection rules — require signed commits.",
            "Implement secret scanning on all git pushes (git-secrets, trufflehog).",
            "Review all third-party webhooks and OAuth app permissions quarterly.",
            "Use immutable infrastructure — never patch live servers, redeploy instead.",
            "Implement SLSA (Supply chain Levels for Software Artifacts) framework.",
        ],
        "fix_example": '<script src="https://cdn.example.com/lib.js"\n  integrity="sha384-xxxx"\n  crossorigin="anonymous"></script>',
        "compliance": ["SLSA Framework", "NIST SP 800-161", "EO 14028 (US Executive Order)"],
    },
    "A09": {
        "name": "Security Logging & Monitoring Failures",
        "risk": "Breaches go undetected for months — average detection time is 197 days without proper monitoring.",
        "what_companies_must_do": [
            "Log all authentication events, access control failures, and input validation errors.",
            "Include: timestamp, user ID, IP address, action, outcome in every log entry.",
            "Ship logs to a centralized SIEM (Splunk, ELK, Datadog) immediately.",
            "Set up real-time alerts for: multiple failed logins, privilege escalation, data exports.",
            "Retain security logs for minimum 12 months (compliance requirement).",
            "Protect logs from tampering — use append-only, write-protected storage.",
            "Never log sensitive data: passwords, credit card numbers, tokens.",
        ],
        "precautions": [
            "Implement anomaly detection on login patterns and API usage.",
            "Test your incident response plan quarterly (tabletop exercises).",
            "Set up uptime monitoring and alert on unexpected downtime.",
            "Create a dedicated security dashboard with real-time metrics.",
            "Establish Mean Time to Detect (MTTD) < 1 hour as a KPI.",
        ],
        "fix_example": "import logging\nlogging.basicConfig(level=logging.WARNING)\napp.logger.warning(f'Failed login: user={username} ip={request.remote_addr}')",
        "compliance": ["PCI-DSS 10.x", "HIPAA §164.312(b)", "SOC 2 CC7.2"],
    },
    "A10": {
        "name": "Server-Side Request Forgery (SSRF)",
        "risk": "Attackers make the server fetch internal resources — bypassing firewalls to reach internal APIs, cloud metadata, or other services.",
        "what_companies_must_do": [
            "Validate and whitelist all URLs that the server is allowed to fetch.",
            "Block requests to private IP ranges: 10.x.x.x, 192.168.x.x, 127.x.x.x, 169.254.x.x.",
            "Disable HTTP redirects when fetching user-supplied URLs.",
            "Use a separate network segment for services that fetch external URLs.",
            "Implement a DNS allowlist — only permitted domains can be resolved.",
            "Return generic errors — never include fetched content in error messages.",
        ],
        "precautions": [
            "Block access to cloud metadata endpoints (169.254.169.254) at network level.",
            "Implement egress filtering — servers should only reach known destinations.",
            "Audit all code that accepts URLs or makes outbound HTTP requests.",
            "Use a dedicated proxy for all outbound requests with allowlist enforcement.",
            "Test SSRF with tools like SSRFmap and Gopherus before every release.",
        ],
        "fix_example": "import ipaddress\ndef is_safe_url(url):\n    parsed = urllib.parse.urlparse(url)\n    ip = socket.gethostbyname(parsed.hostname)\n    return not ipaddress.ip_address(ip).is_private",
        "compliance": ["NIST SP 800-41", "CIS Control 12", "Cloud Security Alliance CCM"],
    },
}


@app.route("/api/alerts")
@login_required
def api_alerts():
    """JSON endpoint for real-time alert polling."""
    from flask import jsonify
    user_id = get_user_id()
    conn    = get_db()
    rows    = conn.execute(
        "SELECT issues, scan_date, url FROM scans WHERE user_id=? ORDER BY id DESC LIMIT 3",
        (user_id,)
    ).fetchall()
    conn.close()

    alerts = []
    for row in rows:
        scan_issues = parse_issues(row["issues"])
        try:
            scanned_at = datetime.datetime.strptime(row["scan_date"], "%Y-%m-%d %H:%M:%S")
            diff = datetime.datetime.utcnow() - scanned_at
            if diff.days > 0:         time_ago = f"{diff.days}d ago"
            elif diff.seconds > 3600: time_ago = f"{diff.seconds//3600}h ago"
            elif diff.seconds > 60:   time_ago = f"{diff.seconds//60}m ago"
            else:                     time_ago = "just now"
        except:
            time_ago = "recently"
        for issue in scan_issues[:3]:
            alerts.append({
                "title":    issue[0],
                "severity": issue[1],
                "category": issue[2],
                "time":     time_ago,
                "url":      row["url"],
            })

    seen_t = set()
    unique = []
    for a in alerts:
        if a["title"] not in seen_t:
            seen_t.add(a["title"])
            unique.append(a)

    return jsonify({
        "alerts":      unique[:8],
        "high_count":  len([a for a in unique if a["severity"] == "HIGH"]),
        "total_count": len(unique),
    })


@app.route("/remediation/<category>")
@login_required
def remediation(category):
    """Full remediation guide for a specific OWASP category."""
    cat_upper = category.upper()
    info = OWASP_REMEDIATION.get(cat_upper)
    if not info:
        return redirect(url_for("home"))
    return render_template("remediation.html", category=cat_upper, info=info)



@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        if not username or not password:
            error = "Please fill in all fields."
        else:
            conn = get_db()
            user = conn.execute(
                "SELECT * FROM users WHERE username = ? AND password = ?",
                (username, hash_password(password))
            ).fetchone()
            conn.close()

            if user:
                session["user"] = username
                return redirect(url_for("home"))
            else:
                error = "Invalid username or password."

    return render_template("login.html", error=error)


@app.route("/signup", methods=["GET", "POST"])
def signup():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm  = request.form.get("confirm", "")
        email    = request.form.get("email", "").strip()

        if not username or not password:
            error = "Username and password are required."
        elif len(password) < 6:
            error = "Password must be at least 6 characters."
        elif password != confirm:
            error = "Passwords do not match."
        else:
            conn = None
            try:
                conn = get_db()
                conn.execute(
                    "INSERT INTO users (username, password, email) VALUES (?, ?, ?)",
                    (username, hash_password(password), email)
                )
                conn.commit()
                session["user"] = username
                return redirect(url_for("home"))
            except sqlite3.IntegrityError:
                error = "Username already exists. Please choose another."
            finally:
                if conn:
                    conn.close()

    return render_template("signup.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ─────────────────────────────────────────────
# MAIN ROUTES
# ─────────────────────────────────────────────

@app.route("/", methods=["GET", "POST"])
@login_required
def home():
    user_id = get_user_id()
    conn    = get_db()

    total_scans   = conn.execute("SELECT COUNT(*) FROM scans WHERE user_id=?", (user_id,)).fetchone()[0]
    avg_row       = conn.execute("SELECT AVG(score) FROM scans WHERE user_id=?", (user_id,)).fetchone()[0]
    avg_score     = round(avg_row or 0)
    total_high    = conn.execute("SELECT SUM(high) FROM scans WHERE user_id=?", (user_id,)).fetchone()[0] or 0

    recent_scans  = conn.execute(
        "SELECT * FROM scans WHERE user_id=? ORDER BY id DESC LIMIT 5", (user_id,)
    ).fetchall()

    last_row = conn.execute(
        "SELECT scan_date FROM scans WHERE user_id=? ORDER BY id DESC LIMIT 1", (user_id,)
    ).fetchone()
    last_scan_date = last_row["scan_date"][:10] if last_row else "Never"

    # ── Real-time alerts from last 3 scans ──
    recent_alert_scans = conn.execute(
        "SELECT issues, scan_date, url FROM scans WHERE user_id=? ORDER BY id DESC LIMIT 3",
        (user_id,)
    ).fetchall()

    alerts = []
    for row in recent_alert_scans:
        scan_issues = parse_issues(row["issues"])
        try:
            scanned_at = datetime.datetime.strptime(row["scan_date"], "%Y-%m-%d %H:%M:%S")
            diff = datetime.datetime.utcnow() - scanned_at
            if diff.days > 0:    time_ago = f"{diff.days}d ago"
            elif diff.seconds > 3600: time_ago = f"{diff.seconds//3600}h ago"
            elif diff.seconds > 60:   time_ago = f"{diff.seconds//60}m ago"
            else:                time_ago = "just now"
        except:
            time_ago = "recently"
        for issue in scan_issues[:3]:
            alerts.append({
                "title":    issue[0],
                "severity": issue[1],
                "category": issue[2],
                "time":     time_ago,
                "url":      row["url"],
            })

    seen_t = set()
    unique_alerts = []
    for a in alerts:
        if a["title"] not in seen_t:
            seen_t.add(a["title"])
            unique_alerts.append(a)

    maturity_score = "N/A"
    if total_scans > 0:
        if avg_score >= 90 and total_high == 0: maturity_score = "A+"
        elif avg_score >= 80 and total_high == 0: maturity_score = "A"
        elif avg_score >= 70: maturity_score = "B"
        elif avg_score >= 50: maturity_score = "C"
        elif avg_score >= 30: maturity_score = "D"
        else: maturity_score = "F"

    conn.close()

    return render_template("index.html",
        total_scans    = total_scans,
        avg_score      = avg_score,
        total_high     = total_high,
        last_scan_date = last_scan_date,
        recent_scans   = recent_scans,
        alerts         = unique_alerts[:8],
        alert_count    = len([a for a in unique_alerts if a["severity"] == "HIGH"]),
        maturity_score = maturity_score
    )


@app.route("/dashboard", methods=["GET", "POST"])
@login_required
def dashboard():
    if request.method == "POST":
        url       = request.form.get("url", "").strip()
        app_type  = request.form.get("app_type", "Web Application")
        auth_type = request.form.get("auth", "No Authentication")

        if not url:
            return redirect(url_for("home"))

        score, high, medium, low, risk_level, insight, issues, issues_str = run_scan(
            url, app_type, auth_type
        )

        user_id = get_user_id()
        conn    = get_db()
        conn.execute("""
            INSERT INTO scans
                (user_id, url, score, high, medium, low, risk_level, insight, issues, app_type, auth_type)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (user_id, url, score, high, medium, low, risk_level, insight, issues_str, app_type, auth_type))
        conn.commit()
        conn.close()

        # Attach remediation info to each issue
        issues_with_remediation = []
        for issue in issues:
            cat  = issue[2]  # e.g. "A01"
            rem  = OWASP_REMEDIATION.get(cat, {})
            issues_with_remediation.append({
                "title":       issue[0],
                "severity":    issue[1],
                "category":    cat,
                "cat_name":    rem.get("name", cat),
                "risk":        rem.get("risk", ""),
                "fix_example": rem.get("fix_example", ""),
                "precautions": rem.get("precautions", []),
                "compliance":  rem.get("compliance", []),
            })

        return render_template("dashboard.html",
            high       = high,
            medium     = medium,
            low        = low,
            risk_level = risk_level,
            insight    = insight,
            issues     = issues_with_remediation,
            url        = url,
            score      = score,
        )

    return redirect(url_for("home"))


@app.route("/history")
@login_required
def history():
    user_id = get_user_id()
    conn    = get_db()

    scans       = conn.execute("SELECT * FROM scans WHERE user_id=? ORDER BY id DESC", (user_id,)).fetchall()
    total_scans = len(scans)
    avg_row     = conn.execute("SELECT AVG(score) FROM scans WHERE user_id=?", (user_id,)).fetchone()[0]
    avg_score   = round(avg_row or 0)
    total_high  = conn.execute("SELECT SUM(high) FROM scans WHERE user_id=?", (user_id,)).fetchone()[0] or 0

    conn.close()

    return render_template("history.html",
        scans       = scans,
        total_scans = total_scans,
        avg_score   = avg_score,
        total_high  = total_high,
    )


@app.route("/report/<int:scan_id>")
@login_required
def report(scan_id):
    user_id = get_user_id()
    conn    = get_db()
    scan    = conn.execute(
        "SELECT * FROM scans WHERE id=? AND user_id=?", (scan_id, user_id)
    ).fetchone()
    conn.close()

    if not scan:
        return redirect(url_for("history"))

    raw_issues = parse_issues(scan["issues"])

    # Enrich each issue with full OWASP remediation data
    issues_full = []
    for issue in raw_issues:
        cat = issue[2]
        rem = OWASP_REMEDIATION.get(cat, {})
        issues_full.append({
            "title":                  issue[0],
            "severity":               issue[1],
            "category":               cat,
            "cat_name":               rem.get("name", cat),
            "risk":                   rem.get("risk", ""),
            "what_companies_must_do": rem.get("what_companies_must_do", []),
            "precautions":            rem.get("precautions", []),
            "fix_example":            rem.get("fix_example", ""),
            "compliance":             rem.get("compliance", []),
        })

    # Group by category for summary section
    categories_hit = {}
    for i in issues_full:
        cat = i["category"]
        if cat not in categories_hit:
            categories_hit[cat] = {"name": i["cat_name"], "high": 0, "medium": 0, "low": 0, "issues": []}
        categories_hit[cat]["issues"].append(i)
        if i["severity"] == "HIGH":   categories_hit[cat]["high"] += 1
        elif i["severity"] == "MEDIUM": categories_hit[cat]["medium"] += 1
        else:                           categories_hit[cat]["low"] += 1

    return render_template("report.html",
        scan            = scan,
        issues          = issues_full,
        categories_hit  = categories_hit,
    )


@app.route("/analysis")
@login_required
def analysis():
    user_id = get_user_id()
    conn    = get_db()

    total   = conn.execute("SELECT COUNT(*) FROM scans WHERE user_id=?", (user_id,)).fetchone()[0]
    avg_row = conn.execute("SELECT AVG(score) FROM scans WHERE user_id=?", (user_id,)).fetchone()[0]
    avg_score = round(avg_row or 0)
    high    = conn.execute("SELECT SUM(high)   FROM scans WHERE user_id=?", (user_id,)).fetchone()[0] or 0
    medium  = conn.execute("SELECT SUM(medium) FROM scans WHERE user_id=?", (user_id,)).fetchone()[0] or 0
    low     = conn.execute("SELECT SUM(low)    FROM scans WHERE user_id=?", (user_id,)).fetchone()[0] or 0

    # Calculate category density for Heatmap (from latest scan)
    cats = {f"A{str(i).zfill(2)}": 0 for i in range(1, 11)}
    latest = conn.execute("SELECT issues FROM scans WHERE user_id=? ORDER BY id DESC LIMIT 1", (user_id,)).fetchone()
    if latest and latest["issues"]:
        raw = parse_issues(latest["issues"])
        for _, _, cat in raw:
            if cat in cats:
                cats[cat] += 1

    conn.close()

    return render_template("analysis.html",
        total     = total,
        avg_score = avg_score,
        high      = high,
        medium    = medium,
        low       = low,
        cats      = cats
    )


@app.route("/delete/<int:scan_id>")
@login_required
def delete_scan(scan_id):
    user_id = get_user_id()
    conn    = get_db()
    conn.execute("DELETE FROM scans WHERE id=? AND user_id=?", (scan_id, user_id))
    conn.commit()
    conn.close()
    return redirect(url_for("history"))


@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    message = None
    if request.method == "POST":
        action = request.form.get("action", "")

        if action == "change_password":
            current = request.form.get("current_password", "")
            new_pw  = request.form.get("new_password", "")
            confirm = request.form.get("confirm_password", "")
            user_id = get_user_id()
            conn    = get_db()
            user    = conn.execute(
                "SELECT * FROM users WHERE id=? AND password=?",
                (user_id, hash_password(current))
            ).fetchone()
            if not user:
                message = ("error", "Current password is incorrect.")
            elif new_pw != confirm:
                message = ("error", "New passwords do not match.")
            elif len(new_pw) < 6:
                message = ("error", "Password must be at least 6 characters.")
            else:
                conn.execute("UPDATE users SET password=? WHERE id=?",
                             (hash_password(new_pw), user_id))
                conn.commit()
                message = ("success", "Password changed successfully.")
            conn.close()

        elif action == "clear_history":
            user_id = get_user_id()
            conn    = get_db()
            conn.execute("DELETE FROM scans WHERE user_id=?", (user_id,))
            conn.commit()
            conn.close()
            message = ("success", "Scan history cleared.")

        elif action == "delete_account":
            user_id = get_user_id()
            conn    = get_db()
            conn.execute("DELETE FROM scans WHERE user_id=?", (user_id,))
            conn.execute("DELETE FROM users WHERE id=?", (user_id,))
            conn.commit()
            conn.close()
            session.clear()
            return redirect(url_for("login"))

    return render_template("settings.html", message=message)


# ─────────────────────────────────────────────
# NEW TOOLS & SCHEDULER
# ─────────────────────────────────────────────

@app.route("/schedule", methods=["GET", "POST"])
@login_required
def schedule():
    user_id = get_user_id()
    conn = get_db()
    
    if request.method == "POST":
        action = request.form.get("action")
        if action == "add":
            url = request.form.get("url", "").strip()
            freq = request.form.get("frequency", "Daily")
            app_type = request.form.get("app_type", "Web Application")
            auth_type = request.form.get("auth", "No Authentication")
            
            if url:
                now = datetime.datetime.utcnow()
                next_run = now.strftime("%Y-%m-%d %H:%M:%S")
                conn.execute("""
                    INSERT INTO scheduled_scans (user_id, url, frequency, next_run, app_type, auth_type)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (user_id, url, freq, next_run, app_type, auth_type))
                conn.commit()
                
        elif action == "delete":
            scan_id = request.form.get("scan_id")
            if scan_id:
                conn.execute("DELETE FROM scheduled_scans WHERE id=? AND user_id=?", (scan_id, user_id))
                conn.commit()
                
    schedules = conn.execute("SELECT * FROM scheduled_scans WHERE user_id=? ORDER BY id DESC", (user_id,)).fetchall()
    conn.close()
    
    return render_template("schedule.html", schedules=schedules)


@app.route("/tools/crawler", methods=["GET", "POST"])
@login_required
def tool_crawler():
    results = None
    url = ""
    if request.method == "POST":
        url = request.form.get("url", "").strip()
        if url:
            if not url.startswith("http"): url = "https://" + url
            try:
                headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'}
                resp = requests.get(url, headers=headers, timeout=10)
                
                if resp.status_code not in [200, 201, 202]:
                    results = {"error": f"Failed to fetch page. Server returned HTTP Status {resp.status_code}. The site might be blocking automated requests or the page does not exist."}
                else:
                    soup = BeautifulSoup(resp.text, "html.parser")
                    base_domain = urllib.parse.urlparse(url).netloc
                    
                    internal = set()
                    external = set()
                    
                    for link in soup.find_all("a", href=True):
                        href = link["href"]
                        full_url = urllib.parse.urljoin(url, href)
                        parsed = urllib.parse.urlparse(full_url)
                        if parsed.scheme in ["http", "https"]:
                            if parsed.netloc == base_domain:
                                internal.add(full_url)
                            else:
                                external.add(full_url)
                                
                    results = {
                        "internal": list(internal)[:100], 
                        "external": list(external)[:100], 
                        "count_int": len(internal), 
                        "count_ext": len(external)
                    }
                    
                    if len(internal) == 0 and len(external) == 0:
                        import re
                        fallback_urls = re.findall(r'(https?://[^\s"\'<>]+)', resp.text)
                        for f_url in fallback_urls:
                            f_parsed = urllib.parse.urlparse(f_url)
                            if f_parsed.netloc == base_domain:
                                internal.add(f_url)
                            else:
                                external.add(f_url)
                        
                        if len(internal) > 0 or len(external) > 0:
                            results = {
                                "internal": list(internal)[:100], 
                                "external": list(external)[:100], 
                                "count_int": len(internal), 
                                "count_ext": len(external),
                                "info": "Links were found via raw source text extraction (no standard anchor tags detected)."
                            }
                        else:
                            results["error"] = "No links were found. The application might be a Single Page Application (SPA) requiring JavaScript to render, or there are genuinely no links on the page."
            except Exception as e:
                results = {"error": f"Connection error: {str(e)}"}
                
    return render_template("crawler.html", results=results, url=url)


@app.route("/tools/subdomain", methods=["GET", "POST"])
@login_required
def tool_subdomain():
    results = None
    domain = ""
    if request.method == "POST":
        domain = request.form.get("domain", "").strip()
        domain = domain.replace("https://", "").replace("http://", "").split("/")[0]
        if domain.startswith("www."):
            domain = domain[4:]
            
        if domain:
            if "." not in domain:
                results = {"error": "Invalid domain format. Please enter a valid domain (e.g., example.com)."}
            else:
                try:
                    subs = set()
                    # 1. Try HackerTarget API first (more reliable, returns CSV)
                    try:
                        ht_resp = requests.get(f"https://api.hackertarget.com/hostsearch/?q={domain}", timeout=10)
                        if ht_resp.status_code == 200 and "error" not in ht_resp.text.lower():
                            for line in ht_resp.text.split("\n"):
                                parts = line.split(",")
                                if parts:
                                    sub = parts[0].strip().lower()
                                    if sub and sub != domain and not sub.startswith("*"):
                                        subs.add(sub)
                    except:
                        pass
    
                    # 2. Try crt.sh as a secondary fallback if HackerTarget didn't find much
                    if len(subs) < 5:
                        try:
                            cr_resp = requests.get(f"https://crt.sh/?q=%.{domain}&output=json", timeout=12)
                            if cr_resp.status_code == 200:
                                data = cr_resp.json()
                                for entry in data:
                                    nav = entry.get("name_value", "")
                                    for n in nav.split("\\n"):
                                        n = n.strip().lower()
                                        if n and n != domain and not n.startswith("*"):
                                            subs.add(n)
                        except:
                            pass
                    
                    if subs:
                        results = {"subdomains": sorted(list(subs))[:200], "count": len(subs)}
                    else:
                        results = {"error": "No subdomains found or upstream APIs (HackerTarget/crt.sh) timed out. Please try again later."}
                except Exception as e:
                    results = {"error": f"Failed to resolve subdomains: {str(e)}"}
                
    return render_template("subdomain.html", results=results, domain=domain)


@app.route("/tools/cookies", methods=["GET", "POST"])
@login_required
def tool_cookies():
    results = None
    url = ""
    if request.method == "POST":
        url = request.form.get("url", "").strip()
        if url:
            if not url.startswith("http"): url = "https://" + url
            try:
                session_req = requests.Session()
                resp = session_req.get(url, timeout=10)
                
                parsed_cookies = []
                for c in session_req.cookies:
                    pc = {
                        "name": c.name,
                        "domain": c.domain,
                        "path": c.path,
                        "secure": c.secure,
                        "httponly": False,
                        "samesite": "None (Missing)"
                    }
                    if c._rest:
                        if 'HttpOnly' in c._rest or 'httponly' in c._rest: pc['httponly'] = True
                        if 'SameSite' in c._rest: pc['samesite'] = c._rest['SameSite']
                        elif 'samesite' in c._rest: pc['samesite'] = c._rest['samesite']
                    parsed_cookies.append(pc)
                    
                results = {"cookies": parsed_cookies, "count": len(parsed_cookies)}
            except Exception as e:
                results = {"error": str(e)}
    return render_template("cookies.html", results=results, url=url)


@app.route("/api/badge")
def api_badge():
    url = request.args.get("url")
    if not url:
        return "Must provide url parameter", 400
    
    conn = get_db()
    scan = conn.execute(
        "SELECT score, risk_level FROM scans WHERE url=? ORDER BY id DESC LIMIT 1", (url,)
    ).fetchone()
    conn.close()

    if not scan:
        score = "?"
        color = "#9ca3af" # gray
    else:
        score = str(scan["score"])
        rl = scan["risk_level"]
        if rl == "LOW": color = "#059669"
        elif rl == "MEDIUM": color = "#d97706"
        else: color = "#dc2626"
        
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="120" height="20">
    <linearGradient id="b" x2="0" y2="100%">
        <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
        <stop offset="1" stop-opacity=".1"/>
    </linearGradient>
    <mask id="a">
        <rect width="120" height="20" rx="3" fill="#fff"/>
    </mask>
    <g mask="url(#a)">
        <path fill="#555" d="M0 0h65v20H0z"/>
        <path fill="{color}" d="M65 0h55v20H65z"/>
        <path fill="url(#b)" d="M0 0h120v20H0z"/>
    </g>
    <g fill="#fff" text-anchor="middle" font-family="DejaVu Sans,Verdana,Geneva,sans-serif" font-size="11">
        <text x="32.5" y="15" fill="#010101" fill-opacity=".3">Security</text>
        <text x="32.5" y="14">Security</text>
        <text x="92.5" y="15" fill="#010101" fill-opacity=".3">{score}%</text>
        <text x="92.5" y="14">{score}%</text>
    </g>
</svg>'''
    from flask import Response
    return Response(svg, mimetype="image/svg+xml", headers={"Cache-Control": "no-cache"})


@app.route("/tools/fix", methods=["GET", "POST"])
@login_required
def tool_fix():
    solution = None
    if request.method == "POST":
        category = request.form.get("category")
        language = request.form.get("language")
        
        fixes = {
            "A01": {
                "Python": "from flask import session, abort\n\n@app.route('/admin')\ndef admin():\n    if not session.get('is_admin'):\n        abort(403)\n    return render_template('admin.html')",
                "Node": "app.get('/admin', (req, res) => {\n  if (!req.session.isAdmin) {\n    return res.status(403).send('Forbidden');\n  }\n  res.render('admin');\n});"
            },
            "A02": {
                "Python": "import bcrypt\n\npassword = b\"super_secret\"\nsalt = bcrypt.gensalt()\nhashed = bcrypt.hashpw(password, salt)\n\n# Verification\nif bcrypt.checkpw(password, hashed):\n    print(\"Match!\")",
                "Node": "const bcrypt = require('bcrypt');\n\nconst saltRounds = 10;\nbcrypt.hash('super_secret', saltRounds, function(err, hash) {\n    // Store hash\n    bcrypt.compare('super_secret', hash, function(err, result) {\n        if(result) console.log('Match!');\n    });\n});"
            },
            "A03": {
                "Python": "import sqlite3\n\n# Secure Parameterized Query\nconn = sqlite3.connect('db.sqlite')\ncursor = conn.cursor()\ncursor.execute('SELECT * FROM users WHERE username = ?', (user_input,))\nuser = cursor.fetchone()",
                "Node": "const { Client } = require('pg');\nconst client = new Client();\n\n// Secure Parameterized Query\nconst values = [userInput];\nclient.query('SELECT * FROM users WHERE username = $1', values, (err, res) => {\n  console.log(res.rows);\n});"
            },
            "A04": {
                "Python": "from flask import Flask, escape, request\n\n@app.route('/')\ndef hello():\n    name = request.args.get(\"name\", \"World\")\n    return f'Hello, {escape(name)}!'",
                "Node": "const express = require('express');\nconst escapeHtml = require('escape-html');\nconst app = express();\n\napp.get('/', (req, res) => {\n  const name = req.query.name || 'World';\n  res.send(`Hello, ${escapeHtml(name)}!`);\n});"
            },
            "A05": {
                "Python": "from flask import Flask\nfrom flask_csp.csp import csp_header\n\napp = Flask(__name__)\n\n@app.route('/')\n@csp_header({'default-src': \"'self'\"})\ndef index():\n    return 'Secure!'",
                "Node": "const helmet = require('helmet');\nconst express = require('express');\nconst app = express();\n\n// Sets up secure HTTP headers\napp.use(helmet());"
            }
        }
        solution = fixes.get(category, {}).get(language, "General mitigation: Validate all inputs, escape outputs, and use principle of least privilege.")
        
    return render_template("fix.html", solution=solution)

@app.route("/tools/simulation")
@login_required
def tool_simulation():
    return render_template("simulation.html")

@app.route("/tools/admin_finder", methods=["GET", "POST"])
@login_required
def tool_admin_finder():
    results = None
    if request.method == "POST":
        url = request.form.get("url", "").strip()
        if url:
            if not url.startswith("http"): url = "https://" + url
            results = []
            paths = ["/admin", "/wp-admin", "/login", "/administrator", "/manager", "/dashboard", "/.git", "/.env", "/config", "/api", "/backup", "/secret", "/cpanel"]
            
            import concurrent.futures
            def check_path(p):
                full_url = url.rstrip('/') + p
                try:
                    r = requests.get(full_url, timeout=5, allow_redirects=False)
                    return {"path": p, "status": r.status_code, "url": full_url}
                except:
                    return {"path": p, "status": 0, "url": full_url}
                    
            with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
                futures = [executor.submit(check_path, p) for p in paths]
                for f in concurrent.futures.as_completed(futures):
                    res = f.result()
                    if res["status"] != 0:
                        results.append(res)
            
            # Sort with lowest numeric status codes first, except group 0 (errors) at the end if you want
            results.sort(key=lambda x: x["status"] if x["status"] > 0 else 999)
            
    return render_template("admin_finder.html", results=results)


# ─────────────────────────────────────────────
# BACKGROUND SCHEDULER
# ─────────────────────────────────────────────

def run_scheduler():
    import time
    from datetime import timedelta
    import datetime as dt
    while True:
        try:
            conn = sqlite3.connect(DB)
            conn.row_factory = sqlite3.Row
            now_dt = dt.datetime.now(dt.timezone.utc).replace(tzinfo=None)
            now_str = now_dt.strftime("%Y-%m-%d %H:%M:%S")
            
            due_scans = conn.execute(
                "SELECT * FROM scheduled_scans WHERE next_run <= ?", (now_str,)
            ).fetchall()
            
            for s in due_scans:
                try:
                    score, high, medium, low, risk_level, insight, issues, issues_str = run_scan(
                        s["url"], s["app_type"], s["auth_type"]
                    )
                    
                    conn.execute("""
                        INSERT INTO scans
                            (user_id, url, score, high, medium, low, risk_level, insight, issues, app_type, auth_type)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (s["user_id"], s["url"], score, high, medium, low, risk_level, insight, issues_str, s["app_type"], s["auth_type"]))
                    
                    now = dt.datetime.now(dt.timezone.utc).replace(tzinfo=None)
                    freq = s["frequency"].lower()
                    if freq == "hourly":
                        next_dt = now + timedelta(hours=1)
                    elif freq == "weekly":
                        next_dt = now + timedelta(days=7)
                    else:
                        next_dt = now + timedelta(days=1)
                        
                    conn.execute(
                        "UPDATE scheduled_scans SET last_run = ?, next_run = ? WHERE id = ?",
                        (now.strftime("%Y-%m-%d %H:%M:%S"), next_dt.strftime("%Y-%m-%d %H:%M:%S"), s["id"])
                    )
                    conn.commit()
                except Exception as e:
                    print(f"Error in scheduled scan for {s['url']}: {e}")
            conn.close()
        except Exception as e:
            print(f"Scheduler error: {e}")
            
        time.sleep(60)

# ─────────────────────────────────────────────
# RUN
# ─────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    import threading
    scheduler_thread = threading.Thread(target=run_scheduler, daemon=True)
    scheduler_thread.start()
    app.run(debug=True, port=5000)